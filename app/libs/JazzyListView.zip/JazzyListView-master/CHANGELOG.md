Change Log
==========

Version 1.2.1 *(2015-03-02)*
----------------------------

* Reduce minSdk to API Level 14

Version 1.2.0 *(2015-02-16)*
----------------------------

* Added jcenter deployment script

Version 1.1.1 *(2015-02-16)*
----------------------------

* Made deploy script tweaks

Version 1.1.0 *(2015-02-16)*
----------------------------

* Add support for jazzy RecyclerView

Version 1.0.1 *(2014-03-14)*
----------------------------

* Build library as .AAR

Version 1.0.0 *(2013-08-28)*
----------------------------

Initial release.